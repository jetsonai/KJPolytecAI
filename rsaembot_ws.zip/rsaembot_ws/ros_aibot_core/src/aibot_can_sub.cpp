#include "ros/ros.h"                         

#include "ros_aibot_core/MsgCtl.h"  
#include <string>
#include <sstream>
#include <pthread.h>
#include <signal.h>
#include "cansocket.hpp"
#include "aibot_core.h"

#define AIBOT_GO 0
#define AIBOT_STOP 1

#define MSG_AIBOT_WHEEL 0x01
#define MSG_AIBOT_ENCODER 0x11
#define MSG_AIBOT_ENC_RESET 0x09

int sendCanTx2(float speed, int dir, float angle, int aibotgo);


#define MotorMin 130 //55
#define MotorMax 255
#define InputMin 0
#define InputMax 1.0

// Map an integer from one coordinate system to another
// This is used to map the servo values to degrees
// e.g. map(90,0,180,servoMin, servoMax)
// Maps 90 degrees to the servo value

int motor_map( float x ) 
{
    if(x >= 1) x = 1;

    int out_min = MotorMin;
    int out_max = MotorMax;
    float in_min= InputMin;
    float in_max= InputMax;
    int ret =(x-in_min)*(out_max-out_min)/(in_max-in_min)+out_min ;
    // For debugging:
    //printf("MAPPED %f to: %d\n", x, ret);
    return ret ;
}

float getmin(float f1, float f2)
{
    if(f1 <= f2)
       return f1;
    else
       return f2;
}

float getmax(float f1, float f2)
{
    if(f1 >= f2)
       return f1;
    else
       return f2;
}

void commandMsgCallback(const ros_aibot_core::MsgCtl::ConstPtr& msg)
{

  //ROS_INFO("goal v[L]:%0.2f [A]:%0.2f\n", goal_velocity_from_cmd[LINEAR], goal_velocity_from_cmd[ANGULAR]);

  float speedCmd = msg->speedCmd;
  float headingCmd = msg->headingCmd;
  uint32_t dirCmd = msg->dirCmd;
  uint32_t stopCmd = msg->stopCmd;
  //printf("[commandMsgCallback] speedCmd:%0.2f headingCmd:%0.2f dirCmd:%d stopCmd:%d\n", speedCmd, headingCmd, dirCmd, stopCmd);
  
  if(speedCmd > 0) {
	  dirCmd = 0; //1;
  } else if (speedCmd < 0) {
	  dirCmd = 1; //0;  
  } 
  speedCmd = abs(speedCmd);
  if (speedCmd == 0 && headingCmd==0) {
	  stopCmd = 1;
  } 
  //printf("speedCmd:%0.2f headingCmd:%0.2f dirCmd:%d stopCmd:%d\n", speedCmd, headingCmd, dirCmd, stopCmd);	   
  sendCanTx2( speedCmd, dirCmd, headingCmd, stopCmd);

  tTime[6] = ros::Time::now().toSec();
}

int sendCanTx2(float speed, int dir, float angle, int aibotgo)
{
    struct can_frame canmsg, res;
    static float pr_speed2, pr_angle;
    static int pr_dir2, pr_aibotgo2;
    int speedL, speedR;

    if(pr_speed2==speed && pr_dir2==dir && pr_angle==angle && pr_aibotgo2==aibotgo) 
    {
        return -1;
    }
    else 
    {
      pr_speed2=speed;
      pr_dir2=dir;
      pr_angle=angle;
      pr_aibotgo2=aibotgo;
    }
	
    ROS_INFO("[sendCanTx2] speed:%0.2f angle:%0.2f dir:%d aibotgo:%d\n", speed, angle, dir, aibotgo);
    float left_x = 0;
    float right_x = 0;
    dirL = dirR = dir;

    if(speed > 0) {   
	//static const float steering_dgain = 0.1;
	//static const float speed_gain = 1.0;

        //steering_gain_value = 0.03;
        //steering_dgain_value = 0.0;
	    static int angle_last;

        float pid = angle * steering_gain_value + (angle - angle_last) * steering_dgain_value;
        angle_last = angle;
	
        float speed_value = speed;
        float steering_value = pid;
    
        left_x = getmax(getmin(speed_value + steering_value, 1.0), 0.0);
        right_x = getmax(getmin(speed_value - steering_value, 1.0), 0.0);

        //
    }

    left_x = left_x * motorLeft;
    right_x = right_x * motorRight;
    ROS_INFO("motorLeft %f motorRight %f left_x %f right_x %f",motorLeft, motorRight,left_x,right_x);

    speedL = motor_map(left_x);
    speedR = motor_map(right_x);
    printf("speedL %d speedR %d dirL %d dirR %d aibotgo %d \n\n", 
	            speedL,speedR, dirL, dirR, aibotgo);
    memset((void*)&canmsg, 0x00, sizeof(struct can_frame));
    canmsg.can_id = MSG_AIBOT_WHEEL;

    canmsg.data[0] = speedR;
    canmsg.data[1] = 0;  
    canmsg.data[2] = dirR;
    canmsg.data[3] = aibotgo; 
    canmsg.data[4] = speedL;
    canmsg.data[5] = 0;  
    canmsg.data[6] = dirL;
    canmsg.data[7] = aibotgo; 	  
	  
	printf("canmsg:%d.%d.%d.%d ", canmsg.data[0],canmsg.data[1],canmsg.data[2],canmsg.data[3]);
	printf("  %d.%d.%d.%d\n", canmsg.data[4],canmsg.data[5],canmsg.data[6],canmsg.data[7]);

#if 1
    if (send_port(&canmsg)) {
        //printf("message sent !!\n");
    } else {
        printf("send fail L\n");
    } 
#endif 
    return 0;   
}

void init_can(void)
{
  if(open_port("can0") < 0)
  {
    printf("open can error:");
    exit(0);

  }
  printf("can0 opened.\n");	
}

void close_can(void)
{
  printf("can0 is closing.\n");
  close_port();	
}

int main(int argc, char **argv)                
{

  ros::init(argc, argv, "aibot_can_sub");  
  ROS_INFO("aibot_can_sub");
        //steering_gain_value = 0.03;
        //steering_dgain_value = 0.0;
  ros::NodeHandle nh;   

  nh.param("/aibot_can_sub/motor_left", motorLeft, 1.0F);
  nh.param("/aibot_can_sub/motor_right", motorRight, 1.0F);
  nh.param("/aibot_can_sub/steering_gain", steering_gain_value, 0.03F);
  nh.param("/aibot_can_sub/steering_dgain", steering_dgain_value, 0.0F);
	
  //motorLeft = 1.0;
  //motorRight = 1.0;
  ROS_INFO("[main] motorLeft %.2f motorRight %.2f",motorLeft, motorRight);
  ROS_INFO("[main] steering_gain %.2f steering_dgain %.2f",steering_gain_value, steering_dgain_value);

  init_can();
  ROS_INFO("aibot Move Ready");

  int status; 

  aibot_can_sub = nh.subscribe("aibot_ctl_msg", 1000, commandMsgCallback);

  ros::spin();

  close_can();
  ROS_INFO("aibot Move End");
  return 0;
}



