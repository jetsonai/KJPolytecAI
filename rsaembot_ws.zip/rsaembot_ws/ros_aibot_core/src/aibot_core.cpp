//#include "ros/ros.h"     
#include "aibot_core.h"
#include <string>
#include <sstream>
#include "ros_aibot_core/MsgCtl.h" 
#include <pthread.h>
#include <signal.h>
#include "cansocket.hpp"

#ifdef IMU_FUNCTION
#include "aibot_imu.h"
#endif

static int fcwCount;
static int rcwCount;
static int ffwCount;
static int rfwCount;

using namespace std;

static volatile bool gRun = true;

void init_can(void);
void init_odom(void);
void reinit_sensors(bool isConnected);
void aibot_setup(void);
//void aibot_loop(void);
void *aibot_loop(void* data);
void close_aibot(void);
#ifdef IMU_FUNCTION
void init_imu(void);
#endif
void sig_int_handler(int sig);
void set_signal(void);
void odom_calculate(int32_t LeftEncoder, int32_t RightEncoder);
int sendCanTx(int speed, int dir, int heading, int aibotgo);
int sendCanTx2(float speed, int dir, float angle, int aibotgo);
void *recvThread(void* data);
void publishDriveInformation(void);
void updateJointStates(void);
void canMsgCallback(const ros_aibot_core::MsgCtl::ConstPtr& msg);
int recvCan2Odom(void);
void updateTFPrefix(void);
int sendInitEnc(void);

/*******************************************************************************
* Callback function for MsgCtl
*******************************************************************************/
void canMsgCallback(const ros_aibot_core::MsgCtl::ConstPtr& msg)
{
  ROS_INFO("recieve speedCmd = %d", msg->speedCmd);  
  ROS_INFO("recieve headingCmd = %d", msg->headingCmd);  
  ROS_INFO("recieve dirCmd = %d", msg->dirCmd);  
  ROS_INFO("recieve stopCmd = %d", msg->stopCmd);

  sendCanTx( msg->speedCmd, msg->dirCmd, msg->headingCmd, msg->stopCmd);

}


int main(int argc, char **argv)                
{
  printf("aibot_core main \n");
  ros::init(argc, argv, "aibot_core2");  

  set_signal();

  gRun = true;
  
  //ros::NodeHandle nh("~");   

  ros::NodeHandle nh;                             
  aibot_can_sub = nh.subscribe("can_ctl_msg", 1000, canMsgCallback);
  odom_pub = nh.advertise<nav_msgs::Odometry>("odom", 500);
 
  cmd_vel_sub = nh.subscribe("cmd_vel", 30, commandVelocityCallback);

  //reset_sub = nh.subscribe("reset", 30, resetCallback);
#ifdef IMU_FUNCTION
  imu_pub = nh.advertise<sensor_msgs::Imu>("imu", 500);
#endif

  joint_states_pub = nh.advertise<sensor_msgs::JointState>("joint_states", 100);

#if 1
  //nh.getParam("/motor_left", motorLeft);
  //nh.getParam("/motor_right", motorRight);
  //ros::param::get("motor_left", motorLeft);
  //ros::param::get("motor_right", motorRight);
  nh.param("/aibot_core/motor_left", motorLeft, 1.0F);
  nh.param("/aibot_core/motor_right", motorRight, 1.0F);
#else
  motorLeft = 1.0;
  motorRight = 1.0;
#endif

  ROS_INFO("[main] motorLeft %f motorRight %f",motorLeft, motorRight);

  ROS_INFO("aibot_core");

  aibot_setup();

#if 1
  tTime[0] = tTime[2] = tTime[3] = ros::Time::now().toSec();

  pthread_t thread_t2;
  if (pthread_create(&thread_t2, NULL, aibot_loop, 0) < 0)
  {
    printf("thread2 create error:");
    exit(0);
  }
#endif


  ros::spin();
  

#if 1
  int status2;
  pthread_join(thread_t2, (void **)&status2);
  printf("Thread2 End %d\n", status2);
#endif

  close_aibot();

  return 0;
}

void aibot_setup(void)
{
  //CAN for Motor Ctl
  init_can();
#ifdef IMU_FUNCTION
  // Setting for IMU
  init_imu();
#endif
  // Setting for SLAM and navigation (odometry, joint states, TF)
  init_odom();

  initJointStates();

  prev_update_time = ros::Time::now().toSec();

  setup_end = true;
}



/*******************************************************************************
* Loop function
*******************************************************************************/

void *aibot_loop(void* data)
{
  ROS_INFO("aibot_loop pub");

  //ros::Rate loop_rate(20);
  //ros::MultiThreadedSpinner spinner(2);
    ros::Rate loop_rate(30);

    while (gRun && ros::ok())
    {

        double t_sec = ros::Time::now().toSec();

	updateTime();
	  //reinit_sensors();
	updateTFPrefix();


	publishDriveInformation();

	#ifdef IMU_FUNCTION

    update_imu_msg();
    sensor_msgs::Imu imu_msg = get_imu_msg();
    imu_pub.publish(imu_msg);

	#endif

        loop_rate.sleep();                  

    }
    printf("end loop thread..\n");
}

int recvCan2Odom(void)
{
     struct can_frame rcvcanmsg;
     memset((void*)&rcvcanmsg, 0x00, sizeof(struct can_frame));

     //printf("waiting message..\n");
     int ret = read_port(&rcvcanmsg);
     if(ret <= 0) {
        printf("no message. stopped.\n");
        return -1;
     } 
	 
     else {
	    if (rcvcanmsg.can_id == 0x11) {
#if 0
	       std::cout << std::hex <<"[recvThread] rcvcanmsg.can_id : 0x"<< rcvcanmsg.can_id << std::endl;
	       printf(">> rcvcanmsg.data[0] 0x%x\n", rcvcanmsg.data[0]);
	       printf(">> rcvcanmsg.data[1] 0x%x\n", rcvcanmsg.data[1]);
	       printf(">> rcvcanmsg.data[2] 0x%x\n", rcvcanmsg.data[2]);
	       printf(">> rcvcanmsg.data[3] 0x%x\n", rcvcanmsg.data[3]);
	       printf(">> rcvcanmsg.data[4] 0x%x\n", rcvcanmsg.data[4]);
	       printf(">> rcvcanmsg.data[5] 0x%x\n", rcvcanmsg.data[5]);
	       printf(">> rcvcanmsg.data[6] 0x%x\n", rcvcanmsg.data[6]);
	       printf(">> rcvcanmsg.data[7] 0x%x\n", rcvcanmsg.data[7]);
#endif
	       double left_enc = interprete32((uint8_t*)rcvcanmsg.data);
	       double right_enc = interprete32((uint8_t*)&rcvcanmsg.data[4]);

	   
	       //printf("[RECV] left_enc:%ld right_enc:%ld\n", left_enc, right_enc);
		   left_enc -= CAN_ENC_OFFSET;
		   right_enc -= CAN_ENC_OFFSET;

	       odom_calculate((int32_t)left_enc, (int32_t)right_enc);
       }
#if 0		
	    else if ( rcvcanmsg.can_id == 0x05)// || rcvcanmsg.can_id == 0x06) 
		    std::cout << std::hex <<"[EMERGENCY] rcvcanmsg.can_id : 0x"<< rcvcanmsg.can_id << std::endl;
		else if (rcvcanmsg.can_id == 0x06) 
		    std::cout << std::hex <<"[EMERGENCY] rcvcanmsg.can_id : 0x"<< rcvcanmsg.can_id << std::endl;
#endif		
#if 1		
			/***** FRONT ******/
            else if(rcvcanmsg.can_id == 0x05) {
				/***** Stop to avoid Collision ******/
				if(rcvcanmsg.data[RX_SENSOR_EMERGENCY1] == 1) {
					//printf("[[[[[[[[ FRONT WARNING !! ]]]]fcwCount:%d\n", fcwCount);
					RunningMode_F = RUN_FCW;
					fcwCount++;		
					if(fcwCount>=10 ) {
						printf("[[[[[[[[ STOP !! ]]]]fcwCount:%d\n\n", fcwCount);	
						RunningMode_F = RUN_STOP;
						sendCanTx2( 0.0f, 0, 0.0f, 1);
					}
                }
				else if(rcvcanmsg.data[RX_SENSOR_EMERGENCY1] == 0){
					RunningMode_F = RUN_DRIVING;
					//printf("[[[[[[[[ FRONT SAFE !! ]]]]fcwCount:%d\n", fcwCount);

					fcwCount = 0;				
				}
				/***** Stop to avoid Falling ******/
				if(rcvcanmsg.data[RX_SENSOR_EMERGENCY2] == 0) {
					printf("[[[ Front] STOP not to fall!! ]]]]ffwCount:%d\n\n", ffwCount);	
					SaftyMode_F = RUN_STOP;
					sendCanTx2( 0.0f, 0, 0.0f, 1);

					ffwCount = 0;	
                }
				else if(rcvcanmsg.data[RX_SENSOR_EMERGENCY2] == 1){
					//printf("[[[[[[[[ FRONT FALL CHECKING !! ]]]]ffwCount:%d\n", ffwCount);
					ffwCount++;		
					if(ffwCount >= 3 ) {
					  SaftyMode_F = RUN_DRIVING;
					  //printf("[[[[[[[[ front BOTTOM SAFE !! ]]]]ffwCount:%d\n", ffwCount);
					}					
				}				
			}
			/***** BACK ******/
            else if(rcvcanmsg.can_id == 0x06) {
				/***** Stop to avoid Collision ******/
				if(rcvcanmsg.data[RX_SENSOR_EMERGENCY1] == 1 ) {
					//printf("[[[[[[[[ BACK WARNING !! ]]]]]rcwCount:%d\n", rcwCount);
					RunningMode_B = RUN_RCW;
					rcwCount++;		
					if(rcwCount>=10 ) {
						printf("[[[[[[[[ STOP !! ]]]]rcwCount:%d\n\n", rcwCount);	
						RunningMode_B = RUN_STOP;
						sendCanTx2(0.0f, 0, 0.0f, 1);
					}
                }
				else if(rcvcanmsg.data[RX_SENSOR_EMERGENCY1] == 0 ){
					RunningMode_B = RUN_DRIVING;					
					//printf("[[[[[[[[ BACK SAFE !! ]]]]]rcwCount:%d\n", rcwCount);

					rcwCount = 0;				
				} 
				/***** Stop to avoid Falling ******/
				if(rcvcanmsg.data[RX_SENSOR_EMERGENCY2] == 0) {
					printf("[[[ Back] STOP not to fall!! ]]]]rfwCount:%d\n\n", rfwCount);	
					SaftyMode_B = RUN_STOP;
					sendCanTx2( 0.0f, 0, 0.0f, 1);

					rfwCount = 0;	
                }
				else if(rcvcanmsg.data[RX_SENSOR_EMERGENCY2] == 1){
					//printf("[[[[[[[[ Back FALL CHECKING !! ]]]]rfwCount:%d\n", rfwCount);
					rfwCount++;		
					if(rfwCount >= 3 ) {
					  SaftyMode_B = RUN_DRIVING;
					  //printf("[[[[[ back BOTTOM SAFE !! ]]]]rfwCount:%d\n", rfwCount);
					}					
				}
			}
#endif			
        //}	   
    }    
    return 0;
}

#define MotorMin 130 //55
#define MotorMax 255
#define InputMin 0
#define InputMax 1.0

// Map an integer from one coordinate system to another
// This is used to map the servo values to degrees
// e.g. map(90,0,180,servoMin, servoMax)
// Maps 90 degrees to the servo value

int motor_map( float x ) 
{
    if(x >= 1) x = 1;

    int out_min = MotorMin;
    int out_max = MotorMax;
    float in_min= InputMin;
    float in_max= InputMax;
    int ret =(x-in_min)*(out_max-out_min)/(in_max-in_min)+out_min ;
    // For debugging:
    //printf("MAPPED %f to: %d\n", x, ret);
    return ret ;
}

float getmin(float f1, float f2)
{
    if(f1 <= f2)
       return f1;
    else
       return f2;
}

float getmax(float f1, float f2)
{
    if(f1 >= f2)
       return f1;
    else
       return f2;
}

int sendInitEnc(void) 
{
	struct can_frame canmsg, res;
    memset((void*)&canmsg, 0x00, sizeof(struct can_frame));
    canmsg.can_id = MSG_AIBOT_ENC_RESET; 

    if (send_port(&canmsg)) {
        //printf("message sent !!\n");
    } else {
        printf("send fail sendInitEnc\n");
    } 
    return 0;	
}

int sendCanTx2(float speed, int dir, float angle, int aibotgo)
{
    struct can_frame canmsg, res;
    static float pr_speed2, pr_angle;
    static int pr_dir2, pr_aibotgo2;
    int speedL, speedR;

    if(pr_speed2==speed && pr_dir2==dir && pr_angle==angle && pr_aibotgo2==aibotgo) 
    {
        return -1;
    }
    else 
    {
      pr_speed2=speed;
      pr_dir2=dir;
      pr_angle=angle;
      pr_aibotgo2=aibotgo;
    }
	
	if(RunningMode_F == RUN_STOP || RunningMode_B == RUN_STOP 
	           || SaftyMode_F == RUN_STOP || SaftyMode_B == RUN_STOP) { 
		aibotgo=1;
	}
	/*if(aibotgo==1) {
		printf("<RunningMode:(%d)(%d)(%d)(%d) >>>>>>>> STOP!!\n", 
		                    RunningMode_F, RunningMode_B, SaftyMode_F, SaftyMode_B);
	}*/
	
    ROS_INFO("[sendCanTx2] speed:%0.2f angle:%0.2f dir:%d aibotgo:%d\n", speed, angle, dir, aibotgo);
    float left_x = 0;
    float right_x = 0;
    dirL = dirR = dir;
    if(speed == 0 && angle != 0) {
        if(angle > 0) { //right side 
            ROS_INFO("Turn right side");
            dirL = 0;//1;
            dirR = 1; //0;	  
        } 
        else if(angle < 0) { //left side
            ROS_INFO("Turn left side");
            dirL = 1; //0;
            dirR = 0; //1;	  
        }
        left_x = right_x = 0.2;
    }

    if(speed > 0) {   
	static const float steering_dgain = 0.1;
	static const float speed_gain = 1.0;	
	static int angle_last;
        float pid = angle * steering_dgain + (angle-angle_last) * steering_dgain;
        angle_last = angle;
	
        float speed_value = speed * speed_gain;
        float steering_value = pid;
    
        left_x = getmax(getmin(speed_value + steering_value, 1.0), 0.0);
        right_x = getmax(getmin(speed_value - steering_value, 1.0), 0.0);

        //
    }

    left_x = left_x * motorLeft;
    right_x = right_x * motorRight;
    //ROS_INFO("motorLeft %f motorRight %f left_x %f right_x %f",motorLeft, motorRight,left_x,right_x);

    speedL = motor_map(left_x);
    speedR = motor_map(right_x);
    printf("speedL %d speedR %d dirL %d dirR %d aibotgo %d Running(%d)(%d) Safety(%d)(%d) ", 
	            speedL,speedR, dirL, dirR, aibotgo, RunningMode_F, 
				RunningMode_B, SaftyMode_F, SaftyMode_B);
    memset((void*)&canmsg, 0x00, sizeof(struct can_frame));
    canmsg.can_id = MSG_AIBOT_WHEEL;
    /*canmsg.data[0] = speedR;
    canmsg.data[1] = 0xA;  
    canmsg.data[2] = dirR;
    canmsg.data[3] = aibotgo; 
    canmsg.data[4] = speedL;
    canmsg.data[5] = 0xA;  
    canmsg.data[6] = dirL;
    canmsg.data[7] = aibotgo; */
    canmsg.data[0] = speedR;
    canmsg.data[1] = 0;  
    canmsg.data[2] = dirR;
    canmsg.data[3] = aibotgo; 
    canmsg.data[4] = speedL;
    canmsg.data[5] = 0;  
    canmsg.data[6] = dirL;
    canmsg.data[7] = aibotgo; 	
  //ROS_INFO("[L]speedCmd= %x dir= %x [R]speedCmd= %x dir= %x \n", canmsg.data[0],
      //canmsg.data[2],canmsg.data[4], canmsg.data[6]);  
	  
	printf("canmsg:%d.%d.%d.%d ", canmsg.data[0],canmsg.data[1],canmsg.data[2],canmsg.data[3]);
	printf("  %d.%d.%d.%d\n", canmsg.data[4],canmsg.data[5],canmsg.data[6],canmsg.data[7]);

#if 1
    if (send_port(&canmsg)) {
        //printf("message sent !!\n");
    } else {
        printf("send fail L\n");
    } 
#endif 
    return 0;   
}


int sendCanTx(int speed, int dir, int heading, int aibotgo)
{
  struct can_frame canmsg, res;
  static int pr_speed, pr_dir, pr_heading, pr_aibotgo;
  int dirL;
  int dirR;

  if(pr_speed==speed && pr_dir==dir && pr_heading==heading && pr_aibotgo==aibotgo) 
  {
      return -1;
  }
  else 
  {
      pr_speed=speed;
      pr_dir=dir;
      pr_heading=heading;
      pr_aibotgo=aibotgo;
  }

  dirL = dirR = dir;
  
  if(heading == 90) {
    dirL = 0;
    dirR = 1;	  
  } else if(heading == -90) {
    dirL = 1;
    dirR = 0;	  
  }
 /*  if(heading == 90) {
    dirL = 1;
    dirR = 0;	  
  } else if(heading == -90) {
    dirL = 0;
    dirR = 1;	  
  } */
  //ROS_INFO("sendCanTx = speed %d heading %d  dirL %d", speed, heading, dirL);
  memset((void*)&canmsg, 0x00, sizeof(struct can_frame));
  canmsg.can_id = MSG_AIBOT_WHEEL;
  canmsg.data[0] = speed;
  canmsg.data[1] = 0xA;  
  canmsg.data[2] = dirL;
  canmsg.data[3] = aibotgo; 
  canmsg.data[4] = speed;
  canmsg.data[5] = 0xA;  
  canmsg.data[6] = dirR;
  canmsg.data[7] = aibotgo; 
  //ROS_INFO("[L]speedCmd= %x dir= %x [R]speedCmd= %x dir= %x \n", canmsg.data[0],
      //canmsg.data[2],canmsg.data[4], canmsg.data[6]);  
	printf("canmsg:%d.%d.%d.%d ", canmsg.data[0],canmsg.data[1],canmsg.data[2],canmsg.data[3]);
	printf(" - %d.%d.%d.%d\n", canmsg.data[4],canmsg.data[5],canmsg.data[6],canmsg.data[7]);
  if (send_port(&canmsg)) {
    //printf("message sent !!\n");
  } else {
    printf("send fail L\n");
  }  
  return 0;   
}

void set_signal(void)
{
  struct sigaction action = {};
  action.sa_handler = sig_int_handler;

  sigaction(SIGHUP, &action, NULL);  // controlling terminal closed, Ctrl-D
  sigaction(SIGINT, &action, NULL);  // Ctrl-C
  sigaction(SIGQUIT, &action, NULL); // Ctrl-\, clean quit with core dump
  sigaction(SIGABRT, &action, NULL); // abort() called.
  sigaction(SIGTERM, &action, NULL); // kill command	
}

void sig_int_handler(int sig)
{
    (void)sig;
    gRun = false;
    close_port();
}

void init_can(void)
{
  if(open_port("can0") < 0)
  {
    printf("open can error:");
    exit(0);

  }
  printf("can0 opened.\n");	
}

void close_aibot(void)
{
  printf("can0 is closing.\n");
  close_port();	
}


/*******************************************************************************
* Callback function for cmd_vel msg
*******************************************************************************/
void commandVelocityCallback(const geometry_msgs::Twist& cmd_vel_msg)
{
  goal_velocity_from_cmd[LINEAR]  = cmd_vel_msg.linear.x;
  goal_velocity_from_cmd[ANGULAR] = cmd_vel_msg.angular.z;

  //ROS_INFO("goal v[L]:%0.2f [A]:%0.2f\n", goal_velocity_from_cmd[LINEAR], goal_velocity_from_cmd[ANGULAR]);

  float speedCmd = 0;
  float headingCmd = 0;
  uint32_t dirCmd = 0;
  uint32_t stopCmd = 0;
  
  speedCmd = goal_velocity_from_cmd[LINEAR];  
  headingCmd = goal_velocity_from_cmd[ANGULAR];

  if(speedCmd > 0) {
	  dirCmd = 0; //1;
  } else if (speedCmd < 0) {
	  dirCmd = 1; //0;
  } 
  speedCmd = abs(speedCmd);
  if (speedCmd == 0 && headingCmd==0) {
	  stopCmd = 1;
  } 
  printf("speedCmd:%0.2f headingCmd:%0.2f dirCmd:%d stopCmd:%d\n", speedCmd, headingCmd, dirCmd, stopCmd);	   
  sendCanTx2( speedCmd, dirCmd, headingCmd, stopCmd);

  tTime[6] = ros::Time::now().toSec();
}

void resetCallback(const std_msgs::Empty& reset_msg)
{
  char log_msg[50];

  (void)(reset_msg);

  init_odom();

  ROS_INFO("Reset Odometry");
 
}

/*******************************************************************************
* Update the base time for interpolation
*******************************************************************************/
void updateTime()
{
  current_offset = ros::Time::now().toSec();

}

/*******************************************************************************
* Update variable (initialization)
*******************************************************************************/
void reinit_sensors(bool isConnected)
{
  static bool variable_flag = false;
  if (isConnected)
  {  
	if (variable_flag == false)
	{    
#ifdef IMU_FUNCTION  
	  init_imu();
#endif
	  init_odom();

	  variable_flag = true;
	}
  }
  else
  {
    variable_flag = false;
  }
}

/*******************************************************************************
* Update TF Prefix
*******************************************************************************/
void updateTFPrefix(void)
{
        sprintf(odom_header_frame_id, "odom"); 
        sprintf(odom_child_frame_id, "base_footprint");  
#ifdef IMU_FUNCTION
        sprintf(imu_frame_id, "imu_link");
#endif
        //sprintf(joint_state_header_frame_id, "base_link");

}

/*******************************************************************************
* Initialization odometry data
*******************************************************************************/
void init_odom(void)
{
    sendInitEnc();

    init_encoder = true;

  for (int index = 0; index < 3; index++)
  {
    odom_pose[index] = 0.0;
    odom_vel[index]  = 0.0;
  }

  odom.pose.pose.position.x = 0.0;
  odom.pose.pose.position.y = 0.0;
  odom.pose.pose.position.z = 0.0;

  odom.pose.pose.orientation.x = 0.0;

  odom.pose.pose.orientation.y = 0.0;
  odom.pose.pose.orientation.z = 0.0;
  odom.pose.pose.orientation.w = 0.0;

  odom.twist.twist.linear.x  = 0.0;
  odom.twist.twist.angular.z = 0.0;
  

}



void odom_calculate(int32_t LeftEncoder, int32_t RightEncoder)
{
  static ros::Time current_time, last_time;

  int32_t deltaLeft, deltaRight;
  static double x = 0;
  static double y = 0;
  static double th = 0;
  double vx, vy, vth;
  double v_left, v_right;  
  double dt, delta_x, delta_y, delta_th; 
  
  RightEncoder = -RightEncoder;

  //printf("LeftEncoder:%d RightEncoder:%d\n", LeftEncoder, RightEncoder);

  current_time = ros::Time::now();

#if 0 //20201221  	
  if((LeftEncoder - PrevLeftEncoder) >= 0)
	deltaLeft = LeftEncoder - PrevLeftEncoder;
  else
	deltaLeft = (RPR_M+LeftEncoder) - PrevLeftEncoder;	  
  if((RightEncoder - PrevRightEncoder) >= 0)
	deltaRight = RightEncoder - PrevRightEncoder;
  else
	deltaRight = (RPR_M+RightEncoder) - PrevRightEncoder;	 
#else
	deltaLeft = LeftEncoder - PrevLeftEncoder;
    deltaRight = RightEncoder - PrevRightEncoder;
#endif  

  //printf("left_enc:%d right_enc:%d deltaLeft:%d deltaRight:%d\n", LeftEncoder, RightEncoder, deltaLeft, deltaRight);

  v_left = (deltaLeft * DistancePerCount) / (current_time - last_time).toSec();
  v_right = (deltaRight * DistancePerCount) / (current_time - last_time).toSec();
  //printf("v_left:%f v_right:%f\n", v_left, v_right);

	vx = ((v_right + v_left) / 2)*10;
	vy = 0;
	vth = ((v_right - v_left)/lengthBetweenTwoWheels)*10;

	dt = (current_time - last_time).toSec();
	delta_x = (vx * cos(th)) * dt;
	delta_y = (vx * sin(th)) * dt;
	delta_th = vth * dt;
  //printf("delta_x:%f delta_y:%f delta_th:%f\n", delta_x, delta_y, delta_th);

	x += delta_x;
	y += delta_y;
	th += delta_th;

	geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(th);

	geometry_msgs::TransformStamped odom_tf;

	odom.header.stamp = current_time;
        odom.header.frame_id = odom_header_frame_id; //"odom"

	//set the position
	odom.pose.pose.position.x = x;
	odom.pose.pose.position.y = y;
	odom.pose.pose.position.z = 0.0;
	odom.pose.pose.orientation = odom_quat;

	//set the velocity
        odom.child_frame_id = odom_child_frame_id; //"base_footprint"
	odom.twist.twist.linear.x = vx;
	odom.twist.twist.linear.y = vy;
	odom.twist.twist.angular.z = vth;

	//publish the message
	odom_pub.publish(odom);
	
	//odom_trans.header.stamp = current_time;
	//odom_trans.header.frame_id = "odom";
	//odom_trans.child_frame_id = "base_footprint";
	odom_tf.header = odom.header;
	odom_tf.child_frame_id = odom.child_frame_id;;
	odom_tf.transform.translation.x = x;
	odom_tf.transform.translation.y = y;
	odom_tf.transform.translation.z = 0.0;
	odom_tf.transform.rotation = odom_quat;

	//send the transform
        static tf::TransformBroadcaster tf_broadcaster;
        odom_tf.header.stamp = current_time;
	tf_broadcaster.sendTransform(odom_tf);
	PrevLeftEncoder = LeftEncoder;
	PrevRightEncoder = RightEncoder;  

    last_velocity[LEFT]  = v_left;
    last_velocity[RIGHT] = v_right;
	
    last_rad[LEFT]       += TICK2RAD * (double)deltaLeft;
    last_rad[RIGHT]       += TICK2RAD * (double)deltaRight;
  
    last_time = current_time;
	
}

/*******************************************************************************
* Initialization joint states data
*******************************************************************************/
void initJointStates(void)
{
  //joint_states.header.frame_id = joint_state_header_frame_id;
  joint_states.name.resize(WHEEL_NUM);
  joint_states.position.resize(WHEEL_NUM);
  joint_states.velocity.resize(WHEEL_NUM);

  joint_states.name[0] = "left_wheel_hinge";
  joint_states.name[1] = "right_wheel_hinge";
  joint_states.header.frame_id = "base_link";

}


/*******************************************************************************
* Publish msgs (odometry, joint states, tf)
*******************************************************************************/
void publishDriveInformation(void)
{
  //ROS_INFO("publishDriveInformation");
  ros::Time stamp_now = ros::Time::now();
/*#ifdef IMU_FUNCTION  
  sensor_msgs::Imu imu_msg = get_imu_msg();
  imu_pub.publish(imu_msg);
#endif*/

  //CAN RECV AND CALCULATE ODOM 
  // PUBLISH ODOM
  // TF BROADCAST
  recvCan2Odom();

  // joint states
  updateJointStates();
  joint_states.header.stamp = stamp_now;
  joint_states_pub.publish(joint_states);
}

/*******************************************************************************
* Update the joint states 
*******************************************************************************/
void updateJointStates(void)
{
  //ROS_INFO("updateJointStates");
  joint_states.position[0] = last_rad[LEFT];
  joint_states.position[1] = last_rad[RIGHT];
  joint_states.velocity[0] = last_velocity[LEFT];
  joint_states.velocity[1] = last_velocity[RIGHT];
}

/*******************************************************************************
* CalcUpdateulate the TF
*******************************************************************************/
void updateTF(geometry_msgs::TransformStamped& odom_tf)
{
  ROS_INFO("updateTF");
  odom_tf.header = odom.header;
  odom_tf.child_frame_id = odom.child_frame_id;
  odom_tf.transform.translation.x = odom.pose.pose.position.x;
  odom_tf.transform.translation.y = odom.pose.pose.position.y;
  odom_tf.transform.translation.z = odom.pose.pose.position.z;
  odom_tf.transform.rotation      = odom.pose.pose.orientation;
}
