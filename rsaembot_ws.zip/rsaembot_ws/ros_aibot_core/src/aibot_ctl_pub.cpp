#include "ros/ros.h"     
#include "ros_aibot_core/MsgCtl.h"  
#include <sstream>
#include <signal.h>

static int countnum = 0;  

ros::Publisher tov_can_pub;                          

int testCANctl(int testcase)
{
  ros_aibot_core::MsgCtl msg; 
  static float speedVal = 0.1;
  static float angleVal = 0.0;
  switch(testcase)
  {
  case 0: // test case speed 200
    msg.speedCmd = 0.1;
    msg.headingCmd  = 0.0;  
    msg.dirCmd  = 1;   
    msg.stopCmd  = 0;                    
    //ROS_INFO("case 0: speedCmd %f headingCmd %f", msg.speedCmd, msg.headingCmd); 
    //ROS_INFO("      : dirCmd %d stopCmd %d", msg.dirCmd, msg.stopCmd);     
    break;

  case 1: // test case increase
    if(speedVal >= 1.0) {
      speedVal=1.0;
    }
    else {
      speedVal+=0.1;
    }
    //ROS_INFO("send msg = speedCmd %d dirCmd %d", msg.speedCmd, msg.headingCmd);  
    msg.speedCmd = speedVal;
    msg.headingCmd  = 0;  
    msg.dirCmd  = 1;
    msg.stopCmd  = 0;                         
    break;

  case 2: // test case decrease
    if(speedVal <= 0.1) {
      speedVal=0.1;
    }
    else {
      speedVal-= 0.1;
    }
    msg.speedCmd = speedVal;
    msg.headingCmd  = 0.0;  
    msg.dirCmd  = 1;  
    msg.stopCmd  = 0;                        
    break;

  case 3: // test case increase angle
    /*if(angleVal >= 0.6) {
      angleVal=0.6;
    }
    else {
      angleVal+=0.1;
    }*/
    angleVal=0.8;
    //ROS_INFO("send msg = speedCmd %d dirCmd %d", msg.speedCmd, msg.headingCmd);  
    msg.speedCmd = speedVal;
    msg.headingCmd  = angleVal;  
    msg.dirCmd  = 1;
    msg.stopCmd  = 0;                         
    break;

  case 4: // test case decrease angle
    /*
    if(angleVal <= -0.6) {
      angleVal=-0.6;
    }
    else {
      angleVal-= 0.1;
    } */
    angleVal=-0.8;
    msg.speedCmd = speedVal;
    msg.headingCmd  = angleVal;  
    msg.dirCmd  = 1;  
    msg.stopCmd  = 0;                        
    break;

  case 5: // test case stop
    msg.speedCmd = 0.2;
    msg.headingCmd  = 0.0;  
    msg.dirCmd  = 1;  
    msg.stopCmd  = 1;                       
    //ROS_INFO("send msg = stopCmd %d", msg.stopCmd);     
    break;

	default:
    break;    
  }

  //ROS_INFO("send msg = speedCmd %f headingCmd %f", msg.speedCmd, msg.headingCmd);  
  tov_can_pub.publish(msg); 

}
/*
---------------------------
Moving around:
        1
   4    5    3
        2

space key, s : force stop
*/
int main(int argc, char **argv)                
{
  ros::init(argc, argv, "aibot_ctl_pub");  
  ros::NodeHandle nh;                         

  int testcase = 5;

  if(argc == 2) {
    testcase = atoi(argv[1]);
    printf("test case : %d\n", testcase); 
  }

  //nh.param("/aibot_ctl_pub/test_case", testcase, 5);
  printf("TestCase : %d\n", testcase); 

  tov_can_pub = nh.advertise<ros_aibot_core::MsgCtl>("aibot_ctl_msg", 500);

  ros::Rate loop_rate(1000);

  //int testcase = 0;


  //testCANctl(testcase);
  while (ros::ok())
  {
    testCANctl(testcase);

    loop_rate.sleep();                   
    ++countnum;                          
  }

  return 0;
}
