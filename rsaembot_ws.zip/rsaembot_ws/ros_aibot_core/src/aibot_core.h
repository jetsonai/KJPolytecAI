#ifndef AIBOT_CORE_CONFIG_H_
#define AIBOT_CORE_CONFIG_H_

#include <ros/ros.h>
#include <ros/time.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Empty.h>
#include <std_msgs/Int32.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <tf/tf.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>

#include <math.h>

//#define IMU_FUNCTION

//#define TICK2RAD                         0.001533981  // 0.087890625[deg] * 3.14159265359 / 180 = 0.001533981f

/*-------------aibot----------------*/
#include <pthread.h>
#include <signal.h>
#include "cansocket.hpp"

#ifdef IMU_FUNCTION
#include "aibot_imu.h"
#endif
/*-------------aibot----------------*/

#define CONTROL_MOTOR_SPEED_FREQUENCY          30   //hz
#define CONTROL_MOTOR_TIMEOUT                  500  //ms
#define IMU_PUBLISH_FREQUENCY                  200  //hz
#define CMD_VEL_PUBLISH_FREQUENCY              30   //hz
#define DRIVE_INFORMATION_PUBLISH_FREQUENCY    30   //hz


#define WHEEL_NUM                        2

#define LEFT                             0
#define RIGHT                            1

#define LINEAR                           0
#define ANGULAR                          1

#define DEG2RAD(x)                       (x * 0.01745329252)  // *PI/180
#define RAD2DEG(x)                       (x * 57.2957795131)  // *180/PI

#define TICK2RAD                         0.001498851  // 0.085877863[deg] * 3.14159265359 / 180 = 0.001533981f

// Callback function prototypes
void commandVelocityCallback(const geometry_msgs::Twist& cmd_vel_msg);
void resetCallback(const std_msgs::Empty& reset_msg);

// Function prototypes
#ifdef IMU_FUNCTION
void publishImuMsg(void);
#endif
void publishSensorStateMsg(void);

ros::Time rosNow(void);
ros::Time addMicros(ros::Time & t, uint32_t _micros); // deprecated

void updateVariable(bool isConnected);
void updateMotorInfo(int32_t left_tick, int32_t right_tick);
void updateTime(void);
void updateOdometry(void);
void updateJoint(void);
void updateTF(geometry_msgs::TransformStamped& odom_tf);
void updateGyroCali(bool isConnected);
void updateGoalVelocity(void);
void updateTFPrefix(bool isConnected);

//void initOdom(void);
void initJointStates(void);

bool calcOdometry(double diff_time);


// Joint(Dynamixel) state 
sensor_msgs::JointState joint_states;

// TF 
geometry_msgs::TransformStamped odom_tf;

// IMU 
//sensor_msgs::Imu imu_msg; --> aibot_imu.cpp:38 line

// Odometry
nav_msgs::Odometry odom;

/*******************************************************************************
* Subscriber
*******************************************************************************/

ros::Subscriber cmd_vel_sub;
ros::Subscriber reset_sub;
ros::Subscriber aibot_can_sub;

/*******************************************************************************
* Publisher
*******************************************************************************/

ros::Publisher joint_states_pub;

#ifdef IMU_FUNCTION
ros::Publisher imu_pub;
#endif

ros::Publisher odom_pub;

/*******************************************************************************
* ROS NodeHandle
*******************************************************************************/
//ros::NodeHandle nh;
ros::Time current_time_val;
uint32_t current_offset;

/*******************************************************************************
* ROS Parameter
*******************************************************************************/
char get_prefix[10];
char* get_tf_prefix = get_prefix;

char odom_header_frame_id[30];
char odom_child_frame_id[30];

#ifdef IMU_FUNCTION
char imu_frame_id[30];
#endif
char joint_state_header_frame_id[30];


/*******************************************************************************
* SoftwareTimer of aibot
*******************************************************************************/
static double tTime[10];

/*******************************************************************************
* Declaration for controllers
*******************************************************************************/
float zero_velocity[WHEEL_NUM] = {0.0, 0.0};
float goal_velocity[WHEEL_NUM] = {0.0, 0.0};
float goal_velocity_from_cmd[WHEEL_NUM] = {0.0, 0.0};


/*******************************************************************************
* Calculation for odometry
*******************************************************************************/
bool init_encoder = true;
int32_t last_diff_tick[WHEEL_NUM] = {0, 0};
double  last_rad[WHEEL_NUM]       = {0.0, 0.0};

/*******************************************************************************
* Update Joint State
*******************************************************************************/
double  last_velocity[WHEEL_NUM]  = {0.0, 0.0};


/*******************************************************************************
* Declaration for SLAM and navigation
*******************************************************************************/
unsigned long prev_update_time;
float odom_pose[3];
double odom_vel[3];

/*******************************************************************************
* Declaration for Battery
*******************************************************************************/
bool setup_end        = false;


/*******************************************************************************
* aibot
*******************************************************************************/

#define AIBOT_GO 0
#define AIBOT_STOP 1

#define MSG_AIBOT_WHEEL 0x01
#define MSG_AIBOT_ENCODER 0x11
#define MSG_AIBOT_ENC_RESET 0x09

#define PI_M 3.141592654

#define CAN_ENC_OFFSET 2147483647

#define lengthBetweenTwoWheels 0.21
#define wheelRadius 0.004

//#define RPR_M (131*16*2)
#define RPR_M (100*13*2)

//#TICK4RAD ((360.0/RPR_M)*(180.0/PI_M))
//#define RPR_M (131*16*2)

#define DistancePerCount ((PI_M * wheelRadius * 2) / RPR_M) // (2*PI*r)/ppr

int32_t PrevLeftEncoder;
int32_t PrevRightEncoder;
int dirL, dirR;

int sendCanTx(int speed, int dir, int heading, int aibotgo);
void *recvThread(void* data);
void sig_int_handler(int sig);
void odom_publisher(int32_t LeftEncoder, int32_t RightEncoder);

ros::Time current_time, last_time;

float motorLeft, motorRight;

float steering_gain_value, steering_dgain_value;

/******************************************************************************/
#define RX_SENSOR_EMERGENCY1 		0
#define RX_SENSOR_DIST_STATE 		1
#define RX_SENSOR_DIST_VALUE_1 		2
#define RX_SENSOR_EMERGENCY2 		3
#define RX_SENSOR_BOTTOM_STATE 		4
#define RX_SENSOR_BOTTOM_VALUE_1 	5
#define RX_SENSOR_BOTTOM_VALUE_2 	6

#define RUN_DRIVING	0
#define RUN_FCW		1
#define RUN_RCW		2
#define RUN_STOP	3

#define RUN_ERROR	5

int RunningMode_F;
int RunningMode_B;

int SaftyMode_F;
int SaftyMode_B;



#endif // AIBOT_CORE_CONFIG_H_

