#!/usr/bin/env python3

import rospy
import cv2
from OpenCV_Functions import *

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from std_msgs.msg import Int32

video_path = '/home/nvidia/road_following2/output01.avi'
gst_str = ("nvarguscamerasrc ! video/x-raw(memory:NVMM), width=(int)224, height=(int)224, format=(string)NV12, framerate=(fraction)60/1 ! nvvidconv flip-method=2 ! video/x-raw, width=(int)224, height=(int)224, format=(string)BGRx ! videoconvert ! video/x-raw, format=(string)BGR ! appsink")
model_path = '/home/nvidia/road_following2/new_model_xy.pth'

from ros_aibot_core.msg import MsgCtl
from ros_object_detect.msg import DetInfo

speedVal = 0.1
angleVal = 0.0

stopCmd = 0

def driveCtl(speedval, angleval, stopCmd):
    global speedVal
    global angleVal  
    global ctl_pub

    if (speedval >= 1.0):
      speedval=1.0

    msg = MsgCtl()
    msg.speedCmd = speedval
    msg.headingCmd = angleval
    msg.dirCmd  = 1 
    msg.stopCmd  = stopCmd 
    #print("speedval:{} angleval:{} stopCmd:{}".format(speedval,angleval, msg.stopCmd)) 
    ctl_pub.publish(msg) 

def all_stop():
    global stopCmd
    speedVal = 0.0 
    stopCmd = 1
    driveCtl(speedVal, angleVal, stopCmd);
    time.sleep(1.0)
    
import cv2
import numpy as np
import sys

MotorRun = True

import torchvision
import torch

import torchvision.transforms as transforms
import torch.nn.functional as F
import PIL.Image


mean = torch.Tensor([0.485, 0.456, 0.406]).cuda().half()
std = torch.Tensor([0.229, 0.224, 0.225]).cuda().half()

def preprocess(image):
    image = PIL.Image.fromarray(image)
    image = transforms.functional.to_tensor(image).to(device).half()
    image.sub_(mean[:, None, None]).div_(std[:, None, None])
    return image[None, ...]

def executeModel(image):
    global angle, angle_last
    global speed_gain_value
    global steering_gain_value

    #print("ex:speed_gain_value:", speed_gain_value ," steering_gain_value:", steering_gain_value)

    xy = model(preprocess(image)).detach().float().cpu().numpy().flatten()
    x = xy[0]
    #y = 0.12
    y = -((0.5 - xy[1]) / 2.0)

    angle = np.arctan2(x, y)

    print('trt_model x %f, y %f angle:%f ' % (x, y, angle))
   
    #speed_value = speed_gain_value

    
    return angle
    '''
    pid = angle * steering_gain_value + (angle - angle_last) * steering_dgain_value
    angle_last = angle

    steering_value = pid + steering_bias_value
    left_motor_value = max(min(speed_value + steering_value, 1.0), 0.0)
    right_motor_value = max(min(speed_value - steering_value, 1.0), 0.0)	

    if MotorRun == True:
        set_speed(left_motor_value, right_motor_value)
    else:
        print('model left_motor_value %f, right_motor_value %f' % (left_motor_value, right_motor_value))
    '''

def imageCopy(src):
    return np.copy(src)
	
def imageProcessing(output):
    angle = executeModel(output)
    return output, angle

def Video(openpath, savepath = None):
    global no_display
    global stopCmd
    cap = cv2.VideoCapture(openpath)
    if cap.isOpened():
        print("Video Opened")
    else:
        print("Video Not Opened")
        print("Program Abort")
        exit()
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(width)
    print(height)
    print('--')

    out = None

    if no_display==0:
        cv2.namedWindow("Input", cv2.WINDOW_GUI_EXPANDED)

    try:
        while cap.isOpened():
            # Capture frame-by-frame
            ret, frame = cap.read()
            if ret:
                # Our operations on the frame come here

                #frame = cv2.resize(frame, dsize=(224, 224), interpolation=cv2.INTER_AREA)
                output, angleVal = imageProcessing(frame)
			
                if no_display==0:
                    cv2.imshow("Input", frame)	
                if MotorRun == True:      
                    driveCtl(speedVal, angleVal, stopCmd);
                    stopCmd = 0
            
            else:
                break

            #if cv2.waitKey(int(1000.0/fps)) & 0xFF == ord('q'):
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    except KeyboardInterrupt:  
        print("key int")
        if MotorRun == True:
            all_stop()
        cap.release()
        if no_display==0:
            cv2.destroyAllWindows()
        return

    print("end")
    # When everything done, release the capture
    cap.release()
    if out is not None:
        out.release()
    if MotorRun == True:
        all_stop()

    
    cap.release()
    if no_display==0:
        cv2.destroyAllWindows()
    return
    
    
if __name__=="__main__":
    global no_display
    #global speed_gain_value
    #global steering_gain_value

    #speed_gain_value = 0.18
    #steering_gain_value = 0.03
    no_display = 0

    #print("speed_gain_value:", speed_gain_value ," steering_gain_value:", steering_gain_value)
    print("no_display:", no_display )

    model = torchvision.models.resnet18(pretrained=False)
    model.fc = torch.nn.Linear(512, 2)
    model.load_state_dict(torch.load(model_path))
    device = torch.device('cuda')
    model = model.to(device)
    model = model.eval().half()
    print("new model ready")


    rospy.init_node("lane_follow_node", disable_signals=True)

    bridge = CvBridge()

    ctl_pub = rospy.Publisher('aibot_ctl_msg', MsgCtl, queue_size=10)

    loop_rate = rospy.Rate(1)

    cam_str = gst_str
    print("cam_str:", cam_str )
    Video(cam_str)
    
  

