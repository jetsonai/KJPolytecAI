#!/usr/bin/env python3

import rospy
import cv2
from OpenCV_Functions import *

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

from std_msgs.msg import Int32

#TODO
rospy.init_node('stoptopic_pub')
pub = rospy.Publisher('stop_cmd', Int32, queue_size=10)

stop_cmd = 1


rate = rospy.Rate(2)

while not rospy.is_shutdown():
    pub.publish(stop_cmd)
    rate.sleep()

