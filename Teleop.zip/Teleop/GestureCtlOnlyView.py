'''
* Gestuture Control for Driver GUI Program
* Version 0.0
* 2025024
* JetsonAI Kate Kim 
* kate.brighteyes@gmail.com
'''

import time
import math
import roslibpy
import keyboard

import cv2
import time
import numpy as np
import cvzone
import math
from time import sleep

from Modules.VKHandTracking import HandDetector
from pynput.keyboard import Controller

from ctypes import cast, POINTER
#from comtypes import CLSCTX_ALL
#from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

from Modules.MHHandTracking import MHandDetector
from cvzone.FaceMeshModule import FaceMeshDetector

ShowImageScreen = True

StateHandDrive = 1
StateSelfDrive = 2
#StateAudio = 3 
StateStop = 3 
StateFan = 4

#CurViewState = StateAudio
CurViewState = StateStop

cap = cv2.VideoCapture(0)
#cap.get(cv2.CAP_PROP_FRAME_WIDTH)

windowWidth = 1280
windowHeight = 720
cap.set(3, windowWidth)
cap.set(4, windowHeight)
 
handDetector = HandDetector(detectionCon=0.8)
MHdetector = MHandDetector(detectionCon=0.8, maxHands=2)
Fdetector = FaceMeshDetector(maxFaces=1)

DTextHAND = "Hand Driving"
DTextSELF = "Autonomous Driving"
CTextEye = "Eye Blinking"
DTextFan = "Fan"
#DTextAudio = "Audio"
DTextStop = "Stop"

btnsleep = 0.01
btnClkTime = 0.36
btnClkLenth = 55

DrivingStatusText = ""
CurStateText = ""
DrivingBtnText = ""
FuncStatusText = ""
BtnFontSize = 3

# Button Constant Variables
menuBtnStartX = 550
btnStartW = (100+50+20)
btnWidth = 100

#keysMenu = [["F", "A", "H", "S"],]
keysMenu = [["F", "D", "S", "A"],]

keysAudio = [["1",],
         ["2",],
         ["3",],         
        ]

keysFan = [["L","R"],
         ["B","I"],        
        ]

leftBtnStartX = 50
leftBtnStartY = (100+100+20)
btnWidth2 = 100

keyboard = Controller()

timer = 0
 
# Eye Blink Count Constant Variables
sleepyblinkCounter = 0
eyeCloseTime1 = 0
sleepyblinkBaseTime1 = 0
counter = 0 
idList = [22, 23, 24, 26, 110, 157, 158, 159, 160, 161, 130, 243]
ratioList = []
color = (255, 0, 255)
alarmshowtime = 0

def SleepyEyeBlinkInit():
    global eyeCloseTime1
    global counter
    global eyeclosecount
    global sleepyblinkCounter  
    global alarmshowtime  
    sleepyblinkCounter = 0
    counter = 0    
    eyeCloseTime1 = 0
    alarmshowtime = 0

def DriveProcess(img, lmList, driveArea, MHdetector, Fdetector):
    global eyeCloseTime1
    global counter
    global idList
    global ratioList
    global color
    global sleepyblinkCounter
    global alarmshowtime

    global CurViewState
    global DrivingStatusText

    x, y = driveArea.pos
    w, h = driveArea.size

    pt1=(x, y)
    pt2=(x + w, y + h)  

    if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:    
        hands, img = MHdetector.findHands(img)  # With Draw
        img, faces = Fdetector.findFaceMesh(img, draw=False)   
        if hands:
            # Hand 1
            hand1 = hands[0]
            lmList1 = hand1["lmList"]  # List of 21 Landmarks points
            bbox1 = hand1["bbox"]  # Bounding Box info x,y,w,h
            centerPoint1 = hand1["center"]  # center of the hand cx,cy
            handType1 = hand1["type"]  # Hand Type Left or Right
            fingers1 = MHdetector.fingersUp(hand1)
    
            if len(hands) == 2:
                hand2 = hands[1]
                lmList2 = hand2["lmList"]  # List of 21 Landmarks points
                bbox2 = hand2["bbox"]  # Bounding Box info x,y,w,h
                centerPoint2 = hand2["center"]  # center of the hand cx,cy
                handType2 = hand2["type"]  # Hand Type Left or Right
    
                fingers2 = MHdetector.fingersUp(hand2)
                length, info, img = MHdetector.findDistance(centerPoint1, centerPoint2, img)  # with draw
        if faces:
            face = faces[0]
            for id in idList:
                tface = tuple(face[id])
                cv2.circle(img, tface, 5, color, cv2.FILLED)

            leftUp = tuple(face[159])
            leftDown = tuple(face[23])
            leftLeft = tuple(face[130])
            leftRight = tuple(face[243])        
            lenghtVer, _ = Fdetector.findDistance(leftUp, leftDown)
            lenghtHor, _ = Fdetector.findDistance(leftLeft, leftRight)
            #print("lenghtVer:{} lenghtHor:{}".format(lenghtVer,lenghtHor ))
    
            cv2.line(img, leftUp, leftDown, (0, 200, 0), 3)
            cv2.line(img, leftLeft, leftRight, (0, 200, 0), 3)
    
            ratio = int((lenghtVer / lenghtHor) * 100)
            #print("<<ratio>>:{}".format(ratio ))
            ratioList.append(ratio)
            if len(ratioList) > 3:
                ratioList.pop(0)
            ratioAvg = sum(ratioList) / len(ratioList)
            if ratioAvg <= 30 and counter == 0:
                eyeCloseTime1 = time.time()
                counter = 1 
                color = (0,200,0)    
            elif (ratioAvg > 30 and eyeCloseTime1>0):  
                closetime = time.time() - eyeCloseTime1    
                if (closetime > 0.4):      
                    sleepyblinkCounter += 1
                    print("sleepyblinkCounter:{}".format(sleepyblinkCounter))
                    eyeCloseTime1 = 0                                                            
            if(counter != 0):
                counter += 1
                if counter > 10:
                    counter = 0
                    color = (255,0, 255)

            img = showEyeBlinkingCount(img, sleepyblinkCounter)

    if(sleepyblinkCounter >= 12 and alarmshowtime == 0):
        print("sleepyblinkCounter:{} You are sleeping !!".format(sleepyblinkCounter))
        sleepyblinkCounter = 0
        alarmshowtime = 1
    #else:
    #    print("sleepyblinkCounter:{} NOT sleeping !!".format(sleepyblinkCounter))
    
    if (alarmshowtime >= 1):
        showSleepyAlarm(img, "Turn to Self Driving.")
        alarmshowtime += 1
        if(alarmshowtime > 15):
            CurViewState = StateSelfDrive
            DrivingStatusText = DTextSELF  
            alarmshowtime = 0

    return img

def StopProcess(img, lmList, driveArea, Fdetector):
    global eyeCloseTime1
    global counter
    global idList
    global ratioList
    global color
    global sleepyblinkCounter
    global alarmshowtime

    global CurViewState

    x, y = driveArea.pos
    w, h = driveArea.size

    pt1=(x, y)
    pt2=(x + w, y + h)  

    if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:    
        img, faces = Fdetector.findFaceMesh(img, draw=False)   

        if faces:
            face = faces[0]
            for id in idList:
                tface = tuple(face[id])
                cv2.circle(img, tface, 5, color, cv2.FILLED)

            leftUp = tuple(face[159])
            leftDown = tuple(face[23])
            leftLeft = tuple(face[130])
            leftRight = tuple(face[243])        
            lenghtVer, _ = Fdetector.findDistance(leftUp, leftDown)
            lenghtHor, _ = Fdetector.findDistance(leftLeft, leftRight)
            #print("lenghtVer:{} lenghtHor:{}".format(lenghtVer,lenghtHor ))
    
            cv2.line(img, leftUp, leftDown, (0, 200, 0), 3)
            cv2.line(img, leftLeft, leftRight, (0, 200, 0), 3)
    
            ratio = int((lenghtVer / lenghtHor) * 100)
            #print("<<ratio>>:{}".format(ratio ))
            ratioList.append(ratio)
            if len(ratioList) > 3:
                ratioList.pop(0)
            ratioAvg = sum(ratioList) / len(ratioList)
            if ratioAvg <= 30 and counter == 0:
                eyeCloseTime1 = time.time()
                counter = 1 
                color = (0,200,0)    
            elif (ratioAvg > 30 and eyeCloseTime1>0):  
                closetime = time.time() - eyeCloseTime1    
                if (closetime > 0.4):      
                    sleepyblinkCounter += 1
                    print("sleepyblinkCounter:{}".format(sleepyblinkCounter))
                    eyeCloseTime1 = 0                                                            
            if(counter != 0):
                counter += 1
                if counter > 10:
                    counter = 0
                    color = (255,0, 255)

            img = showEyeBlinkingCount(img, sleepyblinkCounter)

    if(sleepyblinkCounter >= 12 and alarmshowtime == 0):
        print("sleepyblinkCounter:{} You are sleeping !!".format(sleepyblinkCounter))
        sleepyblinkCounter = 0
        alarmshowtime = 1

    
    if (alarmshowtime >= 1):
        showSleepyAlarm(img, "Turn to Self Driving.")
        alarmshowtime += 1
        if(alarmshowtime > 15):
            CurViewState = StateSelfDrive
            DrivingStatusText = DTextSELF  
            alarmshowtime = 0

    return img

def drawGrdBtn(img, buttonList, color):
    for button in buttonList:
        x, y = button.pos
        w, h = button.size
        cvzone.cornerRect(img, (button.pos[0], button.pos[1], button.size[0], button.size[1]),
                          (30), rt=0)
        pt1=(x, y)
        pt2=(x + w, y + h)
        #color=(255 ,0, 255)
        cv2.rectangle(img, pt1, pt2, color, 5, cv2.FILLED)
        cv2.putText(img, button.text, ((x + 10), y + 65),
                    cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4)
    return img

def PasteImgROI(image, x1, y1, dst):
    h, w = image.shape[:2]
    #dst[x1:x1+w, y1:y1+h] = image
    dst[y1:y1+h, x1:x1+w] = image
    return dst



def drawWndPowerSelect(img, button):
    global imgfan
    global windPower
    #windPower = 3
    x, y = button.pos
    w, h = button.size
    cvzone.cornerRect(img, (button.pos[0], button.pos[1], button.size[0], button.size[1]),
                          (30), rt=0)
    pt1=(x, y)
    pt2=(x + w, y + h)
    color=(255 ,255, 0)

    x2 = 1100
    y2 = 200
    imgW = imgfan.shape[1]
    if(windPower >= 1):
        img = PasteImgROI(imgfan, x2, (y2+3*imgW), img) 
    if(windPower >= 2):
        img = PasteImgROI(imgfan, x2, (y2+2*imgW), img)   
    if(windPower >= 3):
        img = PasteImgROI(imgfan, x2, (y2+1*imgW), img) 
    if(windPower >= 4):
        img = PasteImgROI(imgfan, x2, (y2), img)                        
   
    cv2.rectangle(img, pt1, pt2, color, 5, cv2.FILLED)

    return img
 
def showDriveStatus(DrivingStatusText):
    cv2.rectangle(img, (50, 10), (265, 60), (175, 0, 175), cv2.FILLED)
    cv2.putText(img, DrivingStatusText, (55, 45),
                cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
    return img   

def showFuncStatus(FuncStatusText):
    cv2.rectangle(img, (50, 90), (180, 140), (175, 0, 175), cv2.FILLED)
    cv2.putText(img, FuncStatusText, (55, 125),
                cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
    return img   

def showWindPower():
    global windPower
    boxX1 = 985
    boxY1 = 660  
    cv2.rectangle(img, (boxX1, boxY1), ((boxX1+270), (boxY1+50)), (175, 175, 0), cv2.FILLED)
    windstring = "Wind Power : "+ str(windPower)
    cv2.putText(img, windstring, ((boxX1+15), (boxY1+30)),
                cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
    return img  

def menuBtnInit(buttonList, keysMenu) :
    for i in range(len(keysMenu)):
        for j, key in enumerate(keysMenu[i]):
            buttonList.append(Button([btnStartW * j + menuBtnStartX, (100) * i + 30], key))   
    return buttonList 

def volumeBtnInit(vbuttonList, keysAudio) :
    for i in range(len(keysAudio)):
        for j, key in enumerate(keysAudio[i]):
            vbuttonList.append(Button([btnStartW * j + leftBtnStartX, (100) * i + (30+200)], key))   
    return vbuttonList 

def fanBtnInit(vbuttonList, keysFan) :
    for i in range(len(keysFan)):
        for j, key in enumerate(keysFan[i]):
            if i == 0:
                vbuttonList.append(Button([(btnStartW) * j + leftBtnStartX, (50+100) * i + (30+200)], key))   
            elif i == 1:
                if j == 0:
                    vbuttonList.append(Button([(btnStartW) * j + leftBtnStartX+80, (50+100) * i + (30+200)], key)) 
    return vbuttonList 

def drawClickFingers(img, points):
    x1, y1, x2, y2, cx, cy = points
    cv2.circle(img, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
    cv2.circle(img, (x2, y2), 15, (255, 0, 255), cv2.FILLED)
    cv2.line(img, (x1, y1), (x2, y2), (255, 0, 255), 3)
    cv2.circle(img, (cx, cy), 15, (255, 0, 255), cv2.FILLED)
    return img

MenuBtnTime1 = 0
def MenuBtnProcess(img, imgInput, buttonList, lmList, DrivingStatusText, FuncStatusText):
    global CurViewState
    global MenuBtnTime1
    for button in buttonList:
        x, y = button.pos
        w, h = button.size

        pt1=(x, y)
        pt2=(x + w, y + h)

        ax, ay = MenuArea.pos
        aw, ah = MenuArea.size

        if ax < lmList[8][0] < ax + aw and ay < lmList[8][1] < ay + ah:
            l, _, points = handDetector.findDistance(8, 12, imgInput, draw=True)
            drawClickFingers(img, points)

            if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
                cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), (175, 0, 175), cv2.FILLED)
                cv2.putText(img, button.text, (x + 10, y + 65),
                            cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4)
                ## when clicked
                if l < btnClkLenth:
                    #print('pressed')
                    MenuBtnTime1 = time.time()                                                                    
                    sleep(btnsleep)
                if(MenuBtnTime1 > 0):
                    keyboard.press(button.text)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 0), cv2.FILLED)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 255), 5) 
                    cv2.putText(img, button.text, (x + 10, y + 65),
                                cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4) 
                    if button.text =='D':
                        print("Drive the Robot")
                        CurViewState = StateHandDrive
                        DrivingStatusText = DTextHAND
                    elif button.text=='A':
                        #Autonomous
                        print("Autonomous Driiving")
                        CurViewState = StateSelfDrive
                        DrivingStatusText = DTextSELF  
                    elif button.text=='F':
                        CurViewState = StateFan
                        FuncStatusText = DTextFan     
                    elif button.text=='S':
                        #print("Stop the Robot")
                        CurViewState = StateStop
                        DrivingStatusText = DTextStop                       
                    timer = time.time() - MenuBtnTime1
                    if (timer > btnClkTime):   
                        MenuBtnTime1 = 0   

    return img , DrivingStatusText, FuncStatusText

def BarCtlProcess(img, lmList, ctldev, AudioCtl):
    x, y = ctldev.volumeArea.pos
    w, h = ctldev.volumeArea.size
    x = x + 50
    y = y + 30
    w = w - 100
    h = h - 30

    pt1=(x, y)
    pt2=(x + w, y + h)

    # You Can Change "fingersDist" for your own fingers !!
    fingersDist = 46

    if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
        volLength, _, points = handDetector.findDistance(4, 8, img, draw=True)
        #print('volume max:{} min{}'.format(ctldev.minVol, ctldev.maxVol))
        #barLenth = 300
        barLength = ctldev.barY2 - ctldev.barY1
        ctldev.vol = np.interp(volLength, [fingersDist, barLength], [ctldev.minVol, ctldev.maxVol])
        ctldev.volBar = np.interp(volLength, [fingersDist, barLength], [ctldev.barY2, ctldev.barY1])
        ctldev.volPer = np.interp(volLength, [fingersDist, barLength], [0, 100])
        print(int(volLength), ctldev.vol)
        if AudioCtl == True:
            ctldev.volume.SetMasterVolumeLevel(ctldev.vol, None)
        cv2.rectangle(img, (ctldev.barX1, ctldev.barY1), (ctldev.barX2, ctldev.barY2), (255, 0, 0), 3)
        cv2.rectangle(img, (ctldev.barX1, int(ctldev.volBar)), (ctldev.barX2, ctldev.barY2), (255, 0, 0), cv2.FILLED)
        cv2.putText(img, f'{int(ctldev.volPer)} %', ((ctldev.barX1+10), (ctldev.barY2+50)), 
                cv2.FONT_HERSHEY_COMPLEX, 1, (255, 0, 0), 3)    
    return img
'''
AudioBtnTime1 = 0
def AudioBtnProcess(img, imgInput, audioBtnList, lmList):
    global AudioBtnTime1

    for button in audioBtnList:
        x, y = button.pos
        w, h = button.size

        pt1=(x, y)
        pt2=(x + w, y + h)

        ax = 0
        ay = volumeDev.AreaY1
        aw = volumeDev.AreaX1
        ah = windowHeight - volumeDev.AreaY1

        if ax < lmList[8][0] < ax + aw and ay < lmList[8][1] < ay + ah:
            l, _, points = handDetector.findDistance(8, 12, imgInput, draw=True)
            drawClickFingers(img, points)
            if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
                cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), (175, 0, 175), cv2.FILLED)
                cv2.putText(img, button.text, (x + 10, y + 65),
                            cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4)

                ## when clicked
                if l < btnClkLenth:
                    print('pressed')
                    AudioBtnTime1 = time.time()                                                                    
                    sleep(btnsleep)
                if(AudioBtnTime1 > 0):
                    keyboard.press(button.text)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 0), cv2.FILLED)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 255), 5) 
                    cv2.putText(img, button.text, (x + 10, y + 65),
                                cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4) 
                    timer = time.time() - AudioBtnTime1
                    if (timer > btnClkTime):   
                        AudioBtnTime1 = 0   
    return img
'''

FanBtnTime1 = 0

def FanBtnProcess(img, imgInput, FanBtnList, lmList):
    global FanBtnTime1
       
    for button in FanBtnList:
        x, y = button.pos
        w, h = button.size

        pt1=(x, y)
        pt2=(x + w, y + h)

        ax = 0
        ay = fanDev.AreaY1
        aw = fanDev.AreaX1
        ah = windowHeight - fanDev.AreaY1

        if ax < lmList[8][0] < ax + aw and ay < lmList[8][1] < ay + ah:
            l, _, points = handDetector.findDistance(8, 12, imgInput, draw=True)
            drawClickFingers(img, points)

            if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
                cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), (175, 0, 175), cv2.FILLED)
                cv2.putText(img, button.text, (x + 10, y + 65),
                            cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4)
                ## when clicked
                if l < btnClkLenth:
                    #print('pressed')
                    FanBtnTime1 = time.time()                                                                    
                    sleep(btnsleep)
                if(FanBtnTime1 > 0):
                    keyboard.press(button.text)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 0), cv2.FILLED)
                    cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 255), 5) 
                    cv2.putText(img, button.text, (x + 10, y + 65),
                                cv2.FONT_HERSHEY_PLAIN, BtnFontSize, (255, 255, 255), 4) 
                    timer = time.time() - FanBtnTime1
                    if (timer > btnClkTime):   
                        FanBtnTime1 = 0                      
    return img


WindBtnTime1 = 0
def WindBtnProcess(img, imgInput, winBtn, lmList):
    global windPower
    global WindBtnTime1

    x, y = winBtn.pos
    w, h = winBtn.size
    windMax = 4

    pt1=(x, y)
    pt2=(x + w, y + h)

    ax = fanDev.AreaX1 + fanDev.AreaW
    ay = fanDev.AreaY1
    aw = windowWidth - ax
    ah = windowHeight - fanDev.AreaY1

    if ax < lmList[8][0] < ax + aw and ay < lmList[8][1] < ay + ah:
        l, _, points = handDetector.findDistance(8, 12, imgInput, draw=True)
        drawClickFingers(img, points)

        if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
            cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), (175, 0, 175))
            ## when clicked
            if l < 55:
                #print(l)   
                WindBtnTime1 = time.time()                                        
                sleep(btnsleep)
            if(WindBtnTime1 > 0):
                cv2.rectangle(img, pt1, (x + w, y + h), (0 , 255, 255), 5) 
                timer = time.time() - WindBtnTime1
                if (timer > btnClkTime):
                    if (windPower < windMax):
                        windPower = windPower+1
                    else:
                        windPower = 1    
                    WindBtnTime1 = 0         
    return img


def showEyeBlinkingCount(img, blinkCounter):
    boxX1 = 480
    boxY1 = 660  
    cv2.rectangle(img, (boxX1, boxY1), ((boxX1+320), (boxY1+50)), (255,0, 255), cv2.FILLED)
    windstring = "Blink Count : "+ str(blinkCounter)
    cv2.putText(img, windstring, ((boxX1+15), (boxY1+30)),
                cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
    return img

def showSleepyAlarm(img, alarmtext):
    boxX1 = 480-20
    boxY1 = 660  
    cv2.rectangle(img, (boxX1, boxY1-10), ((boxX1+320+40), (boxY1+50+10)), (255,0, 255), cv2.FILLED)
    cv2.putText(img, alarmtext, ((boxX1+15), (boxY1+30)),
                cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
    return img

imgcar = cv2.imread("c:/Teleop/img/car.png")
imgcar = cv2.resize(imgcar, dsize=(210,330), interpolation=cv2.INTER_AREA) 

def drawFanPositionBtn(img, imgcar, fanBtnList):
    colorsiver = 122
    colorsiver2 = 92
    img = PasteImgROI(imgcar, 80, (180), img) 
    cv2.rectangle(img, (80, 180), ((80+210), (180+330)), (colorsiver, colorsiver, colorsiver), 5) 
    cv2.rectangle(img, (80+2, 180+2), ((80+210-4), (180+330-4)), (colorsiver2, colorsiver2, colorsiver2), 3) 
    img = drawGrdBtn(img, fanBtnList, (255,255,0))  
    return img

def drawTempAutoDrivingFrame(img, cap2):
    if(cap2.get(cv2.CAP_PROP_POS_FRAMES) == cap2.get(cv2.CAP_PROP_FRAME_COUNT)):
        cap2.set(cv2.CAP_PROP_POS_FRAMES, 0)         
    res, frame = cap2.read()
    if (res==False):
        print("empty")
        frame = cap2lastframe   
    frame = cv2.resize(frame, dsize=(600,500), interpolation=cv2.INTER_AREA)
    cap2lastframe = frame
    img = PasteImgROI(frame, 380, (158), img)   
    return img
  
def GestureProcess(img, menuBtnList, DriveArea, audioBtnList, fanBtnList, windBtn):
    global CurViewState
    global DrivingStatusText
    global FuncStatusText
    #global volumeDev
    global fanDev
    global imgcar

    imgInput = img.copy()
    if ShowImageScreen == True:
        if CurViewState == StateHandDrive: #or CurViewState == StateSelfDrive: 
            img = AddBG(imgDriveBGGr, img)
        else:
            img = AddBG(imgControlBGGr, img)
            
    imgInput = handDetector.findHands(imgInput, False)
    lmList, bboxInfo = handDetector.findPosition(imgInput, False)
  
    img = drawGrdBtn(img, menuBtnList, (255 ,0, 255))

    #if CurViewState == StateStop:
    #    print("stop")
    #    img = drawGrdBtn(img, audioBtnList, (255,255,0))    
    #elif CurViewState == StateFan: 
    if CurViewState == StateFan:        
        img = drawFanPositionBtn(img, imgcar, fanBtnList)
        img = drawWndPowerSelect(img, windBtn)
    volLength = 0

    if lmList:
        img, DrivingStatusText, FuncStatusText = MenuBtnProcess(img, imgInput, menuBtnList, lmList, DrivingStatusText, FuncStatusText)  

        if CurViewState == StateHandDrive: 
            img = DriveProcess(img, lmList, DriveArea, MHdetector, Fdetector)
        elif CurViewState == StateStop: 
            img = StopProcess(img, lmList, DriveArea, Fdetector)  
            #img = AudioBtnProcess(img, imgInput, audioBtnList, lmList)
        elif CurViewState == StateFan:  
            img = BarCtlProcess(img, lmList, fanDev, False)              
            img = FanBtnProcess(img, imgInput, fanBtnList, lmList)
            img = WindBtnProcess(img, imgInput, windBtn, lmList)

    if CurViewState == StateFan:        
        img = showWindPower()

    img = showDriveStatus(DrivingStatusText)
    #if CurViewState == StateAudio or CurViewState == StateFan:
    #    img = showFuncStatus(FuncStatusText) 
    return img    

class Button():
    def __init__(self, pos, text, size=[btnWidth, 90]):
        self.pos = pos
        self.size = size
        self.text = text

class FunctionArea():
    def __init__(self, pos, size):
        self.pos = pos
        self.size = size

class VolumeDevice():        
    def __init__(self, vol, volBar, volPer, useVolumeDevice):
        if(useVolumeDevice == True):
            '''
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(
                IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            self.volume = cast(interface, POINTER(IAudioEndpointVolume))
            # volume.GetMute()
            # volume.GetMasterVolumeLevel()
            
            volRange = self.volume.GetVolumeRange()
            self.minVol = volRange[0]
            self.maxVol = volRange[1]
            '''            
        else:
           self.minVol = -65.25 
           self.maxVol = 0

        self.vol = vol
        self.volBar = volBar
        self.volPer = volPer
        self.AreaX1 = 380
        self.AreaY1 = 200
        self.AreaW = 600
        self.AreaH = 500  
        self.barX1 = self.AreaX1+40
        self.barY1 = 100+150
        self.barX2 = self.barX1+35
        self.barY2 = 520             
        self.volumeArea = FunctionArea([self.AreaX1, self.AreaY1], [self.AreaW,self.AreaH])           

class FanDevice():        
    def __init__(self, vol, volBar, volPer):
        self.minVol = -65.25
        self.maxVol = 0
        self.vol = vol
        self.volBar = volBar
        self.volPer = volPer
        boxX1 = 380
        boxY1 = 200
        boxW = 600
        boxH = 500  
        self.barX1 = boxX1+40
        self.barY1 = 100+150
        self.barX2 = self.barX1+35
        self.barY2 = 520             
        self.volumeArea = FunctionArea([boxX1, boxY1], [boxW,boxH])         
        

def AddBG(img1, img2):
    height1, width1 = img1.shape[:2]
    x = 0
    y = 0
    w = width1
    h = height1

    chromakey = img1
    offset = 20

    hsv_chroma = cv2.cvtColor(chromakey, cv2.COLOR_BGR2HSV)
    hsv_img = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)

    chroma_h = hsv_chroma[:,:,0]
    lower = np.array([chroma_h.min()-offset, 100, 100])
    upper = np.array([chroma_h.max()+offset, 255, 255])

    mask = cv2.inRange(hsv_img, lower, upper)
    mask_inv = cv2.bitwise_not(mask)
    roi = img2[y:h, x:w]
    fg = cv2.bitwise_and(img1, img1, mask=mask_inv)
    bg = cv2.bitwise_and(roi, roi, mask=mask)
    img2[y:h, x:w] = fg + bg
    return img2

  
DrivingStatusText = DTextStop
FuncStatusText = DTextFan 
menuBtnList = []
menuBtnList = menuBtnInit(menuBtnList, keysMenu)

audioBtnList = []
audioBtnList = volumeBtnInit(audioBtnList, keysAudio)

fanBtnList = []
fanBtnList = fanBtnInit(fanBtnList, keysFan)

windBtn = Button([(1100-3), (200-3)], "", size=[(110+6), (440+3)])
windPower = 1

pTime = 0

#volumeDev = VolumeDevice(0, 400, 0, True)
fanDev = VolumeDevice(0, 400, 0, False)

MenuArea = FunctionArea([0, 0], [windowWidth,(200)])
DriveArea = FunctionArea([200, 158], [880, 500])

imgfan = cv2.imread("c:/Teleop/img/fan.png")
imgfan = cv2.resize(imgfan, dsize=(110,110), interpolation=cv2.INTER_AREA)

imgControlBGGr = cv2.imread("c:/Teleop/img/bg_control_green.png")
imgDriveBGGr = cv2.imread("c:/Teleop/img/bg_drive_green.png")

cap2 = cv2.VideoCapture("c:/Teleop/img/carsim.mp4")
global cap2lastframe

while True:
    success, img = cap.read()
    img = cv2.flip(img, 1)

    img = GestureProcess(img, menuBtnList, DriveArea, audioBtnList, fanBtnList, windBtn)

    if( CurViewState == StateSelfDrive):
        img = drawTempAutoDrivingFrame(img, cap2) 

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break





